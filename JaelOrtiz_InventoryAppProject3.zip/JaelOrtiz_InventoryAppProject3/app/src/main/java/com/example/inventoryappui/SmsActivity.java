package com.example.inventoryappui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

// This screen is only for checking and requesting SMS permission.
public class SmsActivity extends AppCompatActivity {

    Button buttonCheckSms, buttonGrantSms;
    TextView textPermissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Connecting all the UI elements to the Java code
        buttonCheckSms = findViewById(R.id.buttonCheckSms);
        buttonGrantSms = findViewById(R.id.buttonGrantSms);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        // This button takes the user back to the login screen
        Button buttonBack = findViewById(R.id.buttonBackToLogin);

        // When the user taps "Check Permission", it shows if SMS is allowed or not
        buttonCheckSms.setOnClickListener(v -> checkPermission());

        // When the user taps "Grant Permission", the phone will show the permission popup
        buttonGrantSms.setOnClickListener(v -> requestSmsPermission());

        // Finishes this activity so the app returns to LoginActivity
        buttonBack.setOnClickListener(v -> {
            finish();
        });
    }

    // This method checks if SEND_SMS permission is already granted
    private void checkPermission() {
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        // Updates the label so the user knows the status
        if (granted) {
            textPermissionStatus.setText("Permission: GRANTED");
        } else {
            textPermissionStatus.setText("Permission: DENIED");
        }
    }

    // This method asks the user to grant SMS permission
    private void requestSmsPermission() {
        requestPermissions(
                new String[]{Manifest.permission.SEND_SMS},
                100
        );
    }

    // This runs after the user taps "Allow" or "Deny" in the system popup
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // User said yes
                textPermissionStatus.setText("Permission: GRANTED");
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();

            } else {

                // User said no
                textPermissionStatus.setText("Permission: DENIED");
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
