package com.example.inventoryappui;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


//This adapter controls how each item appears inside the RecyclerView.

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private Context context;
    private ArrayList<ItemModel> itemList;
    private DBHelper dbHelper;

    // This constructor gives the adapter what it needs: the screen context,
    // the list of items, and the database helper so I can update or delete data.
    public ItemAdapter(Context context, ArrayList<ItemModel> itemList, DBHelper dbHelper) {
        this.context = context;
        this.itemList = itemList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {

        ItemModel item = itemList.get(position);

        // Show the name and quantity inside the row
        holder.txtName.setText(item.getItemName());
        holder.txtQuantity.setText(String.valueOf(item.getQuantity()));

        // ---------------------------
        // DELETE ITEM BUTTON
        // ---------------------------
        holder.btnDelete.setOnClickListener(v -> {
            // Delete from the actual database first
            dbHelper.deleteItem(item.getId());

            // Then remove it from the ArrayList so the UI matches the DB
            itemList.remove(position);

            // These notify methods tell the RecyclerView that something changed
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, itemList.size());
        });

        // ---------------------------
        // EDIT ITEM BUTTON
        // ---------------------------
        holder.btnEdit.setOnClickListener(v -> {

            // I used an AlertDialog to let the user change the item name and quantity
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Edit Item");

            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(40, 20, 40, 10);

            // Text input for editing the name
            EditText editName = new EditText(context);
            editName.setHint("Item Name");
            editName.setText(item.getItemName()); // Pre-fills the existing value
            layout.addView(editName);

            // Text input for editing the quantity
            EditText editQuantity = new EditText(context);
            editQuantity.setHint("Quantity");
            editQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);
            editQuantity.setText(String.valueOf(item.getQuantity()));
            layout.addView(editQuantity);

            builder.setView(layout);

            // Save button updates both the database and the list
            builder.setPositiveButton("Save", (dialog, which) -> {
                String newName = editName.getText().toString().trim();
                int newQty = Integer.parseInt(editQuantity.getText().toString().trim());

                // Update inside the database
                dbHelper.updateItem(item.getId(), newName, newQty);

                // Update inside the ArrayList so the UI refreshes
                itemList.get(position).setItemName(newName);
                itemList.get(position).setQuantity(newQty);

                // Tells the RecyclerView that only this row changed
                notifyItemChanged(position);
            });

            builder.setNegativeButton("Cancel", null);

            builder.show();
        });
    }

    @Override
    public int getItemCount() {
        // RecyclerView asks how many rows it should display
        return itemList.size();
    }

    // The ViewHolder is a small class that stores
    // the references to the TextViews and Buttons inside each row.
    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView txtName, txtQuantity;
        Button btnDelete, btnEdit;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            // Connect the Java variables to the XML views
            txtName = itemView.findViewById(R.id.txtItemName);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }
}
