package com.example.inventoryappui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    // Input boxes where the user types the item name and quantity
    EditText editName, editQuantity;

    // Button used to add a new item
    Button btnAdd;

    // The RecyclerView that will show all the items in a list
    RecyclerView recyclerView;

    // Database helper so I can interact with SQLite
    DBHelper dbHelper;

    // Adapter that connects the list of items to the RecyclerView
    ItemAdapter adapter;

    // Actual list that holds all the inventory items from the database
    ArrayList<ItemModel> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Setting up the database
        dbHelper = new DBHelper(this);

        // Connecting the UI elements from the XML to the Java variables
        editName = findViewById(R.id.editTextItemName);
        editQuantity = findViewById(R.id.editTextQuantity);
        btnAdd = findViewById(R.id.buttonAddItem);
        recyclerView = findViewById(R.id.recyclerViewItems);

        // Load existing items from the database so they show up when the screen opens
        itemList = dbHelper.getAllItems();

        adapter = new ItemAdapter(this, itemList, dbHelper);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        btnAdd.setOnClickListener(v -> {

            // Get the user's input
            String name = editName.getText().toString().trim();
            String qtyText = editQuantity.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convert the quantity from text into a number
            int quantity = Integer.parseInt(qtyText);

            boolean inserted = dbHelper.addItem(name, quantity);

            if (inserted) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();

                // Reload the list from the database so the new item appears
                itemList.clear();
                itemList.addAll(dbHelper.getAllItems());
                adapter.notifyDataSetChanged();

                // Clear the input boxes after adding
                editName.setText("");
                editQuantity.setText("");
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
