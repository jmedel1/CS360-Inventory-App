package com.example.inventoryappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

// This class handles everything related to the SQLite database.
public class DBHelper extends SQLiteOpenHelper {

    // Name and version of the database
    public static final String DB_NAME = "inventory.db";
    public static final int DB_VERSION = 1;

    // Table + column names for users
    public static final String TABLE_USERS = "users";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Table + column names for items
    public static final String TABLE_ITEMS = "items";
    public static final String COL_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_QUANTITY = "quantity";

    // Constructor – tells SQLiteOpenHelper what DB we are working with
    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // This runs only once when the database is created for the first time.
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create table for user accounts
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)");

        // Create table for inventory items
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER)");
    }

    // This only runs if the database version changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ----------------------------------------------------
    // USER LOGIN FUNCTIONS
    // ----------------------------------------------------

    // This function makes a new user and saves it to the DB.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);

        // If insert returns -1, something went wrong
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    // This checks if the username + password match something in the database.
    public boolean verifyLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password});

        boolean success = cursor.getCount() > 0;
        cursor.close();
        return success;
    }

    // ----------------------------------------------------
    // INVENTORY CRUD FUNCTIONS (Create, Read, Update, Delete)
    // ----------------------------------------------------

    // Add a new inventory item to the list.
    public boolean addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, name);
        cv.put(COL_QUANTITY, quantity);

        long result = db.insert(TABLE_ITEMS, null, cv);
        return result != -1;
    }

    // Get every item stored in the database.
    public ArrayList<ItemModel> getAllItems() {
        ArrayList<ItemModel> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);

        // Loop through all rows returned and turn them into ItemModel objects
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUANTITY));

                list.add(new ItemModel(id, name, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    // Delete an item based on its ID
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_ITEMS, COL_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // Update an existing item (used for the Edit button)
    public boolean updateItem(int id, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, name);
        cv.put(COL_QUANTITY, quantity);

        int rows = db.update(TABLE_ITEMS, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}
