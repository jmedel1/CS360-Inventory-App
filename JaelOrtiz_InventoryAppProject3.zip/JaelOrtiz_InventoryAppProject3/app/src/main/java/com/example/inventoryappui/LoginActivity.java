package com.example.inventoryappui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// This is the login screen for the app.
public class LoginActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button buttonLogin, buttonCreateAccount, buttonOpenSms;

    // Using the database helper to check login and save accounts
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Set up the database
        dbHelper = new DBHelper(this);

        // Connect the UI elements from the XML file
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonOpenSms = findViewById(R.id.buttonOpenSms);

        // -------- LOGIN BUTTON --------
        // When the user taps login, we compare their username + password with the database
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the username + password match what’s in the DB
            if (dbHelper.verifyLogin(username, password)) {
                Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                // If login works, it takes you to the inventory page
                startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            } else {
                Toast.makeText(LoginActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
        });

        // -------- CREATE ACCOUNT BUTTON --------
        // When pressed, it saves a new username + password into the users table
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // createUser() returns true if it's saved successfully
            boolean inserted = dbHelper.createUser(username, password);

            if (inserted) {
                Toast.makeText(LoginActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
            } else {
                // This usually happens if the username already exists (primary key)
                Toast.makeText(LoginActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });

        // -------- SMS SETTINGS BUTTON --------
        // Opens the screen where the user can check or grant SMS permission
        buttonOpenSms.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, SmsActivity.class))
        );
    }
}
