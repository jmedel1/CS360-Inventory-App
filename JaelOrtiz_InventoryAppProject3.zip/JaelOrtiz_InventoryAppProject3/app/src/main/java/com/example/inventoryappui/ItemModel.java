package com.example.inventoryappui;

// This is a model class that holds the data for each item.
public class ItemModel {

    // These are the pieces of data each item needs
    private int id;
    private String name;
    private int quantity;

    // When we create a new ItemModel, we pass in all the values here
    public ItemModel(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // -------- GETTERS --------
    // These return the values so other classes can read them

    public int getId() {
        return id;
    }

    public String getItemName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    // -------- SETTERS --------
    // I needed these so the Edit feature can update the name/quantity

    public void setItemName(String newName) {
        this.name = newName;
    }

    public void setQuantity(int newQuantity) {
        this.quantity = newQuantity;
    }
}
